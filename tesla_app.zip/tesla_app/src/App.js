import React, { useEffect } from 'react';
import './App.css';
import Header from './Components/Header';
import Home from './Components/Home';
import AOS from 'aos';
import 'aos/dist/aos.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Cars from './Components/Cars'; // Import your Cars component
import ErrorBoundary from './Components/ErrorBoundary'; // Import ErrorBoundary
import Account from './Components/Account';
import SubAccount from './Components/SubAccount';
import CreateAccount from './Components/CreateAccount';

function App() {
  useEffect(() => {
    AOS.init({ duration: 2000 });
  }, []);

  return (
    <div className="App">
      <ErrorBoundary>
        <Router>
          <Header />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/model-s" element={<Cars img="model-s.jpg" model="Model S" desc="Order online for touchless delivery" />} />
            <Route path="/model-3" element={<Cars img="model-3.jpg" model="Model 3" desc="Order online for touchless delivery" />} />
            <Route path="/model-x" element={<Cars img="model-x.jpg" model="Model X" desc="Order online for touchless delivery" />} />
            <Route path="/model-y" element={<Cars img="model-y.jpg" model="Model Y" desc="Order online for touchless delivery" />} />
            <Route path="/solar-panel" element={<Cars img="solar-panel.jpg" model="Solar Panel" desc="Order online for touchless delivery" />} />
            <Route path="/solar-roof" element={<Cars img="solar-roof.jpg" model="Solar Roof" desc="Order online for touchless delivery" />} />
            <Route path="/new-interior" element={<Cars img="new-interior.jpg" model="New Interior" desc="Order online for touchless delivery" />} />
            <Route path="/accessories" element={<Cars img="accessories.jpg" model="Accessories" />} />
            <Route path="/subaccount" element={<SubAccount  img="audio.jpg" />}/>

            <Route path="/account" element={<Account img="audio.jpg" />} />

            <Route path="/createaccount" element={<CreateAccount img="audio.jpg" />} />
          </Routes>
        </Router>
      </ErrorBoundary>
    </div>
  );
}

export default App;

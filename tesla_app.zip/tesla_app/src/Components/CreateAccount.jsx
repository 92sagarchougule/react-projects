import React from 'react';
import './CreateAccount.css';
import { useRef } from 'react';

function CreateAccount({img}) {

    const name = useRef(null);
    const email = useRef(null);
    const password = useRef(null);

    const handleSubmit = e => {


        e.preventDefault();

        const data = { nm: name.current.value, em: email.current.value, ps: password.current.value };
        console.log(data);
        alert(data.nm)

    }


    return (
        <>

            <div className='acCreateSection' style={{ backgroundImage: `url("/images/${img}")`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>

                <p className="title">Registration Form</p>

                <form className="form" onSubmit={handleSubmit}>
                    <input ref={name} type="text" placeholder='your name' />
                    <input ref={email} type="email" placeholder=' your email' />
                    <input ref={password} type="password" placeholder='password' />
                    <input type={"submit"}
                        style={{ backgroundColor: "#a1eafb" }} />
                </form>

            </div>
        </>
    );


}

export default CreateAccount;

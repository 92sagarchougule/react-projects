import React from 'react'


function Cars({ img, model, desc }) {
    return (
        <div className='CarSection' style={{ backgroundImage: `url("/images/${img}")`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>

            <div className='carModel'>
                <div data-aos="fade"> {model}</div>
                <p data-aos="fade"> {desc}</p>
            </div>

            <div className='buttonGrp'>
                <button className='btn1'> Custom Order </button>
                {desc && <button className='btn2'> Existing Inventory</button>}
            </div>


        </div>
    )
}

export default Cars;

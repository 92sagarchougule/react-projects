import React from 'react';
import Cars from './Cars';
import { Routes, Route } from 'react-router-dom';  // Import Routes and Route for routing
import Account from './Account';
import SubAccount from './SubAccount';
// import CreateAccount from './CreateAccount';



function Home() {
  return (
    <div>
      <Routes>
        {/* All routes inside Home will now be matched under this wildcard path */}
        <Route path="*" element={<Cars img="model-s.jpg" model="Model S" desc="Order online for touchless delivery" />} />
        <Route path="model-s" element={<Cars img="model-s.jpg" model="Model S" desc="Order online for touchless delivery" />} />
        <Route path="model-3" element={<Cars img="model-3.jpg" model="Model 3" desc="Order online for touchless delivery" />} />
        <Route path="model-x" element={<Cars img="model-x.jpg" model="Model X" desc="Order online for touchless delivery" />} />
        <Route path="model-y" element={<Cars img="model-y.jpg" model="Model Y" desc="Order online for touchless delivery" />} />
        <Route path="solar-panel" element={<Cars img="solar-panel.jpg" model="Solar Panel" desc="Order online for touchless delivery" />} />
        <Route path="solar-roof" element={<Cars img="solar-roof.jpg" model="Solar Roof" desc="Order online for touchless delivery" />} />
        <Route path="new-interior" element={<Cars img="new-interior.jpg" model="New Interior" desc="Order online for touchless delivery" />} />
        <Route path="accessories" element={<Cars img="accessories.jpg" model="Accessories" />} />
        <Route path="subaccount" element={<SubAccount img="audio.jpg" />} />

        <Route path="account" element={<Account img="audio.jpg" />} />
        {/* <Route path="/createaccount" element={<CreateAccount img="audio.jpg" />} /> */}
      </Routes>
    </div>
  );
}

export default Home;

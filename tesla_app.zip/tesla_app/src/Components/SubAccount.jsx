import React, { useState } from "react";

import './SubAccount.css'
import Account from "./Account";

import { useNavigate } from 'react-router-dom'; 

function SubAccount({ img }) {

    const navigate = useNavigate();  // Initialize the navigation hook

    // Handle button click to navigate to the Account page
    const handleAccount = () => {
        navigate('/account');  // Navigate to the "/account" route
    };


    const handleCreateAccount = ()=>{
        navigate('/createaccount');
    }
   
    return (
        <>
            <div className='subaccSection' style={{ backgroundImage: `url("/images/${img}")`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center', opacity:'0.7'}}>

                <div className="subacbuttonGrp">

                    <button className="subacbtn1" onClick={()=>{handleAccount()}}> Login Account </button>

                    <button className="subacbtn2" onClick={()=>{handleCreateAccount()}}> Create Account </button>

                </div>
            </div>
        </>
    )
}
export default SubAccount;
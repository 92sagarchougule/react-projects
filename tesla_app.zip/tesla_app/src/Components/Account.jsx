// Account.js
import React from 'react';

function Account({ img, user, password }) {
  return (
  
      <div className='AccountSection' style={{ backgroundImage: `url("/images/${img}")`, backgroundRepeat: 'no-repeat', backgroundSize: 'cover', backgroundPosition: 'center' }}>


        <div className='loginpage'>
          <div>
            <label htmlFor="user"> Username :
              <input type="text" id="user" name="user" placeholder='Sagar' />
            </label>
          </div>

          <div>
            <label htmlFor="pass"> Password :
              <input type="password" id="pass" name="pass" />
            </label>
          </div>

          <button onClick={()=>{alert('Please write code further for save in database')}}> Submit</button>

        </div>
      </div>
   
  );
}

export default Account;

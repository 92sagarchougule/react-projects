import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useNavigate } from 'react-router-dom'; 


function Header() {
  const [navBar, setNavBar] = useState(false);

  const [minMenu, setmainMenu] = useState(true);

  const navigate = useNavigate();

  const homepage = ()=>{

    navigate('/');

  }

  return (
    <div>
      <nav>
        <img src='/images/logo.svg' alt='tesla' onClick={()=>{homepage()}} />

        {minMenu && <div className='mainMenu'>
          <Link to="/model-s">Model S</Link>
          <Link to="/model-3">Model 3</Link>
          <Link to="/model-x">Model X</Link>
          <Link to="/model-y">Model Y</Link>
          <Link to="/solar-panel">Solar-Panel</Link>
          <Link to="/solar-roof">Solar-Roof</Link>
          <Link to="/new-interior">New Interior</Link>
          <Link to="/accessories">Accessories</Link>
        </div>}

        <div className='rightMenu'>
          <div className='rightTwo'>
            <Link to="#">Shop</Link>
            <Link to="/subaccount" onClick={() => { setmainMenu(false) }}>Account</Link>
          </div>

          {/* Changed <a> to <button> for better accessibility */}
          <a onClick={() => { setNavBar(true) }}> Menu </a>
        </div>

        {navBar && (
          <div data-aos="fade-left" className='mobile'>
            <button onClick={() => { setNavBar(false) }} className='closeButton'>X</button>
            <Link to="/model-s">Model S</Link>
            <Link to="/model-3">Model 3</Link>
            <Link to="/model-x">Model X</Link>
            <Link to="/model-y">Model Y</Link>
            <Link to="/solar-panel">Solar-Panel</Link>
            <Link to="/solar-roof">Solar-Roof</Link>
            <Link to="/new-interior">New Interior</Link>
            <Link to="/accessories">Accessories</Link>
          </div>
        )}
      </nav>
    </div>
  );
}

export default Header;

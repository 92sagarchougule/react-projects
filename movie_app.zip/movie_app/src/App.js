import logo from './logo.svg';
import './App.css';
import Movie from './Components/Movie';

function App() {
  return (
    <div className="App">
      <Movie />
    </div>
  );
}

export default App;

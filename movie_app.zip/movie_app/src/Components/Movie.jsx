import React, { useEffect, useState } from "react";
import axios from "axios";

function Movie() {

    const [movie, setMovie] = useState([]);



    console.log("default movie is :" + movie);

    // function 
    const headers = {
        'Content-Type': 'application/json'
    }


    useEffect(() => {

        getMovie(headers);


    }, [])


    async function getMovie(headers) {
        try {

            const res = await axios.get("https://www.omdbapi.com/?i=tt3896198&apikey=e3e4960b&s=rings", { headers });
            const data = res.data;
            console.log(data);

            setMovie(data.Search)


        } catch (error) {

        }
    }



    return (
        <>
            <div className="home"> {movie.map(el => 
                (<div className="card" key={el.imdbID}>
                <h4> {el.Title} </h4>
                <img src={`${el.Poster}`}></img>
            </div>))}
            </div>
        </>
    )

}

export default Movie;
